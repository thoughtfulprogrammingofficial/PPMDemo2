
Partial Class Admin_AdminMasterPage
    Inherits System.Web.UI.MasterPage
End Class

