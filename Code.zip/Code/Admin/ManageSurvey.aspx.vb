Imports System.Data
Imports System.Data.SqlClient
Imports System.Net.Mail

Partial Class Admin_CreateSurvey
    Inherits System.Web.UI.Page

    Protected Sub DetailsView1_ItemCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DetailsViewCommandEventArgs) Handles DetailsView1.ItemCommand
        If e.CommandName = "Invite" Then
            Dim cnn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
            Dim cmd As New SqlCommand("select * from surveyparticipants where surveyid=@id", cnn)
            Dim p1 As New SqlParameter("@id", DetailsView1.SelectedValue)
            cmd.Parameters.Add(p1)
            Dim da As New SqlDataAdapter
            da.SelectCommand = cmd
            Dim ds As New DataSet
            da.Fill(ds, "participants")
            Dim client As New SmtpClient()
            For Each row As DataRow In ds.Tables("participants").Rows
                client.Send(ConfigurationManager.AppSettings("webmasteremail"), row("email"), "Invitation to participate in our survey", "Please take the survey at the following URL :" & vbCrLf & "http://" & Request.Url.Host & "/survey.aspx?id=" & DetailsView1.SelectedValue)
            Next
            Label3.Text = "Invitations sent successfully!"
        End If
    End Sub
End Class
