Imports System.Data
Imports System.Data.SqlClient

Partial Class Admin_SurveyStats
    Inherits System.Web.UI.Page

    Protected Sub DataList1_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles DataList1.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim questionid As Integer
            questionid = CInt(CType(e.Item.FindControl("Label3"), Label).Text)
            Dim cnn As New SqlConnection(ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
            Dim cmd As New SqlCommand("select * from surveychoices where questionid=@qid", cnn)
            Dim p1 As New SqlParameter("@qid", questionid)
            cmd.Parameters.Add(p1)
            Dim da As New SqlDataAdapter
            da.SelectCommand = cmd
            Dim ds As New DataSet
            da.Fill(ds, "choices")
            cnn.Open()
            For Each row As DataRow In ds.Tables("choices").Rows
                Dim cmdAns As New SqlCommand("select count(*) from surveyanswers where choiceid=@cid", cnn)
                Dim pCid As New SqlParameter("@cid", row("choiceid"))
                cmdAns.Parameters.Add(pCid)
                Dim count As Integer = cmdAns.ExecuteScalar()
                row("Choice") = row("Choice") & " - " & count
            Next
            cnn.Close()
            Dim list As BulletedList = e.Item.FindControl("BulletedList1")
            list.DataSource = ds
            list.DataTextField = "Choice"
            list.DataBind()
        End If

    End Sub

    Protected Sub DataList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataList1.SelectedIndexChanged

    End Sub
End Class
